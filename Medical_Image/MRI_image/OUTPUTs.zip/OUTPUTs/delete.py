import numpy as np

# Ensure dice_scores is a NumPy array
dice_scores = np.array(dice_scores, dtype=float)  # Convert explicitly to float

# Print for debugging
print("Dice Scores:", dice_scores)
print("Data Type:", dice_scores.dtype)

# Compute mean
average_dice = np.mean(dice_scores)
print("Average Dice Score:", average_dice)

